#include <iostream>

using namespace std;

int main()
{
    cout<<"Exception Handling"<<endl;

    char value = 'C';

    try
    {
        if(value == 23)
            throw 23;
        if(value == 10.2f)
            throw 10.2f;
        if(value == 'A')
            throw 'A';

        cout<<"Try - Block"<<endl;
    }

    catch(int e)
    {
        cout<<"Exception is:"<<e<<endl;
    }

    catch(float e)
    {
        cout<<"Exception is:"<<e<<endl;
    }

    catch(char e)
    {
        cout<<"Exception is:"<<e<<endl;
    }

    cout<<"Outside the try-catch block"<<endl;

    return 0;
}
