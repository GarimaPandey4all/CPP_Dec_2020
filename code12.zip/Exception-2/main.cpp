#include <iostream>

using namespace std;

void Myfunc()
{
    if(4 > 3)
    throw 10;
}

int main()
{
    try
    {
        Myfunc(); // function calling

        cout<<"Try - Block"<<endl;
    }

    catch(...)
    {
        cout<<"Exception here"<<endl;
    }

    return 0;
}
