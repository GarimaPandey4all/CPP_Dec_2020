#include <iostream>

using namespace std;

class Add
{
public:
    int a, b;

    void Sum(int a, int b)
    {
        cout<<"Addition is:"<<(a + b)<<endl;
    }
};

int main()
{
    Add obj;
    Add obj2;

    obj.Sum(10, 20);
    obj2.Sum(4, 5);

    return 0;
}
