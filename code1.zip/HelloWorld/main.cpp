#include <iostream> // input/output stream

using namespace std;

int main()
{
    cout << "Hello world!" << endl; // cout: print the output on output screen
    //endl: same as \n - new line

    return 0;
}
