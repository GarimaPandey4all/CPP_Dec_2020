#include <iostream>

using namespace std;

class HelloWorld
{
public: // Access Modifiers/Specifiers: Public, Private, Protected

    void showData()
    {
        cout<<"Hello World";
    }
};

int main()
{
    HelloWorld obj;

    obj.showData();

    return 0;
}
