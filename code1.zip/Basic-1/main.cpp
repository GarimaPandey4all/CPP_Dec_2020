#include <iostream>

using namespace std;

int main()
{
    int a, b;

    cout<<"Enter any number for a and b:";
    cin>>a>>b;

    cout<<"Addition is:"<<(a + b);

    return 0;
}
