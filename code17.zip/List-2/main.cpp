#include <iostream>
#include <list>

using namespace std;

int main()
{
    list <string> l1 {"Mumbai", "New Delhi"};

    l1.push_back("Kerala");

    l1.push_front("Jammu");

    list <string> :: iterator ptr = l1.begin();

    while(ptr != l1.end())
    {
        cout<<*ptr<<" ";
        ++ptr;
    }

    cout<<"\nTotal values in list are:"<<l1.size()<<endl;

    l1.pop_back();

    l1.pop_front();

    list <string> :: iterator ptr1 = l1.begin();

    while(ptr1 != l1.end())
    {
        cout<<*ptr1<<" ";
        ++ptr1;
    }

    cout<<"\nTotal values in list are:"<<l1.size()<<endl;

    return 0;
}
