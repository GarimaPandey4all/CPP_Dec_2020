#include <iostream>
#include <list>

using namespace std;

int main()
{
//    list <int> l1;
//
//    list <int> l3 {10, 20, 30, 40, 50, 60, 70, 80};

    list <string> l1 {"Mumbai", "New Delhi"};

    //cout<<l1[0]; // error

    list <string> :: iterator ptr = l1.begin();

    while(ptr != l1.end())
    {
        cout<<*ptr<<" ";
        ++ptr;
    }

    cout<<"\nTotal values in list are:"<<l1.size()<<endl;

    return 0;
}
