#include <iostream>
#include <map>

using namespace std;

int main()
{
    map <int, string> customer;

    //First Way: Insertion

    customer[100] = "Akshika" ;
    customer[145] = "Rahul" ;
    customer[160] = "Ujjwal" ;
    customer[101] = "Brain" ;
    customer[110] = "Mentors" ;

    //Second Way: Insertion

    map <int, string> c2 {{100, "Akshika"}, {145, "Rahul"}};

    return 0;
}
