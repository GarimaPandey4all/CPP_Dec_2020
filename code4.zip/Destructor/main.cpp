#include <iostream>

using namespace std;

class HelloWorld
{
public:
    //constructor
    HelloWorld()
    {
        cout<<"Constructor"<<endl; // endl - new line
    }

    //destructor
    ~HelloWorld() // ~ - tilte
    {
        cout<<"Destructor"<<endl;
    }
};

int main()
{
    HelloWorld obj;

    return 0;
}
