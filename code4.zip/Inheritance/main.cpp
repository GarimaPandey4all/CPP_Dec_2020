#include <iostream>

using namespace std;

/*
    Inheritance: Code Reuse ability

    Parent - Child Relationship

    Base Class / Parent Class

    Derived Class / Child Class

    Inheritance has five types:

    1. Single Inheritance
    2. Multiple Inheritance
    3. Multilevel Inheritance
    4. Hierarchical Inheritance
    5. Hybrid Inheritance
*/

//Single Inheritance

//Parent Class
class Human
{
public:
    Human()
    {
        cout<<"This is Parent Class"<<endl;
    }
};

//Child Class
class Person : public Human // : - Inheritance
{
public:
    int a;

    Person()
    {
        a = 10;
        cout<<"This is Child Class "<<a<<endl;
    }
};


int main()
{
    Person obj;

    return 0;
}
