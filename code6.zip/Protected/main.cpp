#include <iostream>

using namespace std;

class Parent
{
protected: // private
    int parent;
};

class Child : public Parent
{
public:
    void setData(int a)
    {
        parent = a;
    }

    void getData()
    {
        cout<<"Parent is:"<<parent<<endl;
    }
};

int main()
{
    Child obj;
    obj.setData(10);
    obj.getData();

    return 0;
}
