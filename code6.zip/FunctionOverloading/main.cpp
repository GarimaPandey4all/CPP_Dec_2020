#include <iostream>

using namespace std;

class Calculator
{
public:
    void Add(int a, int b)
    {
        cout<<"Addition is:"<<(a + b)<<endl;
    }

    void Add(float a, float b)
    {
        cout<<"Addition is:"<<(a + b)<<endl;
    }

    void Sub(int a, int b)
    {
        cout<<"Subtraction is:"<<(a - b)<<endl;
    }

    void Sub(float a, float b)
    {
        cout<<"Subtraction is:"<<(a - b)<<endl;
    }

    void Mul(int a, int b)
    {
        cout<<"Multiplication is:"<<(a * b)<<endl;
    }

    void Mul(float a, float b)
    {
        cout<<"Multiplication is:"<<(a * b)<<endl;
    }

    void Div(int a, int b)
    {
        cout<<"Division is:"<<(a / b)<<endl;
    }

    void Div(float a, float b)
    {
        cout<<"Division is:"<<(a / b)<<endl;
    }
};

int main()
{
    Calculator obj;

    obj.Add(10, 20);
    obj.Add(10.67f, 8.79f);

    obj.Sub(10, 20);
    obj.Sub(10.67f, 8.79f);

    obj.Mul(10, 20);
    obj.Mul(10.67f, 8.79f);

    obj.Div(10, 20);
    obj.Div(10.67f, 8.79f);

    return 0;
}
