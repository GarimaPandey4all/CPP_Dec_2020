#include <iostream>

using namespace std;

class VarAssign
{
private:
    int a, b;

public:
  void Assign(int a, int b)
    {
        this.a = a;
        this.b = b;
    }
};

int main()
{
    VarAssign obj;

    obj.Assign(10, 20);

    return 0;
}
