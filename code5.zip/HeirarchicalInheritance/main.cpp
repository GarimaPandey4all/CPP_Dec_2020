#include <iostream>

using namespace std;

class Vehicle // Parent Class
{
public:
    Vehicle()
    {
        cout<<"This is Vehicle Class"<<endl;
    }
};

//Child Class
class Car : public Vehicle
{
public:
    Car()
    {
        cout<<"This is Car class"<<endl;
    }
};


//Child Class
class Bus : public Vehicle
{
public:
    Bus()
    {
        cout<<"This is Bus class"<<endl;
    }
};

int main()
{
    Car obj1;
    Bus obj2;

    return 0;
}
