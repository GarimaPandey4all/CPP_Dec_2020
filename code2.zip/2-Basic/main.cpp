#include <iostream>

using namespace std;

class Cal
{
public:
    int a, b; // data members

    void Add(int x, int y) // member functions
    {
        a = x; // instance variable = local variable
        b = y;
    }

    void display()
    {
        cout<<"Addition is:"<<(a + b);
    }
};

int main()
{
    Cal obj;
    obj.Add(10, 20);

    obj.display();

    return 0;
}
