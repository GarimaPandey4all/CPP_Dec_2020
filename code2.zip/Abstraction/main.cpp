#include <iostream>

using namespace std;

class Abstraction
{
private:
    int a, b;

public:
    //setter
    void setData(int x, int y)
    {
        a = x;
        b = y;
    }

    //getter
    void getData()
    {
        cout<<"a is:"<<a<<endl;
        cout<<"b is:"<<b<<endl;
    }
};

int main()
{
    Abstraction obj;
    obj.setData(4, 7);
    obj.getData();

    return 0;
}
