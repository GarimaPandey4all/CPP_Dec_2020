#include <iostream>

using namespace std;

class Encapsulation
{
public:
    int number;

    void isEven(int n)
    {
        ((n % 2) == 0)? cout<<"Number is Even" : cout<<"Number is Odd";
    }
};

int main()
{
    Encapsulation obj;
    obj.isEven(14);

    return 0;
}
