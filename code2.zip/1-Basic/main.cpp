#include <iostream>

using namespace std;

class HelloWorld
{
    //Access Specifiers/Modifiers: public, private, and protected

public:
    void showData()
    {
        cout<<"Hello World";
    }
};

int main()
{
    HelloWorld obj;

    obj.showData();

    return 0;
}
