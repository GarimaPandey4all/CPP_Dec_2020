#include <iostream>
#include <array>

using namespace std;

//Array Container in STL provides us the implementation of static array.

int main()
{
    array<int, 5> data_array = {10, 20, 30, 40, 50};

    array<int, 5> data_array2 = {1, 2, 3, 4, 5};

    //at()

    cout<<"Value is:"<<data_array.at(2)<<endl;

    //[]

    cout<<"Value is:"<<data_array[4]<<endl;

    //front()

    cout<<"Value is:"<<data_array.front()<<endl;

    //back()

    cout<<"Value is:"<<data_array.back()<<endl;

    //fill()

    data_array.fill(60);

    cout<<"After used fill() the values of an array are:\n";
    for(int i = 0; i < 5; i++)
    {
        cout<<data_array[i]<<"  ";
    }

    cout<<endl;

    //swap()

    data_array.swap(data_array2);

    cout<<"Array -1:\n";
    for(int i = 0; i < 5; i++)
    {
        cout<<data_array[i]<<"  ";
    }

    cout<<endl;


    cout<<"Array -2:\n";
    for(int i = 0; i < 5; i++)
    {
        cout<<data_array2[i]<<"  ";
    }

    cout<<endl;

    //size()

    cout<<"Size of Array -1:"<<data_array.size()<<endl;
    cout<<"Size of Array -2:"<<data_array2.size()<<endl;

    return 0;
}
