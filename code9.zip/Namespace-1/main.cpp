#include <iostream>

using namespace std;

namespace first
{
    int value = 500;

    void showData()
    {
        cout<<"Hello World - 1"<<endl;
    }
}

namespace second
{
    int value = 700;

    void showData()
    {
        cout<<"Hello World - 2"<<endl;
    }
}

//Global Variable
int value = 100;

int main()
{
    //local variable
    int value = 200;

    cout<<"Value is:"<<value<<endl;

    cout<<"Value is:"<<first::value<<endl;

    //std::cout << "Hello world!" << std::endl;

    first::showData();

    cout<<"Value is:"<<second::value<<endl;

    second::showData();

    return 0;
}
