#include <iostream>

using namespace std;

class Student
{
private:
    string name;
    int age;

public:
    void setData(string n, int a)
    {
        name = n;
        age = a;
    }

    void getData()
    {
        cout<<"Name of the Student is:"<<name<<endl;
        cout<<"Age of the Student is:"<<age<<endl;
    }
};


int main()
{
    Student obj;
    obj.setData("Brain", 10);

    pair <string, int> p1;
    pair <string, string> p2;
    pair <string, float> p3;
    pair <int, Student> p4;

    //Insert values in a pair
    p1 = make_pair("Akshika", 20);
    p2 = make_pair("Brain", "Mentors");
    p3 = make_pair("Akshika", 45.67f);
    p4 = make_pair(25, obj);

    //Accessing values from the pair
    cout<<"Pair 1:"<<p1.first<<" "<<p1.second<<endl;
    cout<<"Pair 2:"<<p2.first<<" "<<p2.second<<endl;
    cout<<"Pair 3:"<<p3.first<<" "<<p3.second<<endl;
    cout<<"Pair 4:"<<p4.first<<endl;

    Student obj1 = p4.second;

    obj1.getData();

    return 0;
}
