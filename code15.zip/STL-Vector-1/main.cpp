#include <iostream>
#include <vector>

using namespace std;

int main()
{
    /*
        Vector: It supports dynamic array.
        Dis: Array size if fixed, no flexibility to grow or shrink during execution.
        Vector can provide memory flexibility.
    */

    vector <int> v1;

    cout<<"Current Capacity is:"<<v1.capacity()<<endl;

    vector <string> v2{"Ujjwal", "Akshika", "Brain", "Mentors"};

    cout<<"Current Capacity is:"<<v2.capacity()<<endl;

    return 0;
}
