#include <iostream>

using namespace std;

class Demo
{
public:
    static void func() // Static Member Function
    {
        cout<<"This is Static Function Block"<<endl;
    }
};

int main()
{
    Demo :: func(); // Calling static member function directly with the class name

    return 0;
}
