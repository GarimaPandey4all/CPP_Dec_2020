#include <iostream>

using namespace std;

class Complex
{
private:
    int real;
    int imag;

public:
    Complex(int r = 0, int i = 0)
    {
        real = r;
        imag = i;
    }

    //Operator Overloading
    Complex operator + (Complex obj)
    {
        Complex temp;

        temp.real = real + obj.real;
        temp.imag = imag + obj.imag;

        return temp;
    }

    void print()
    {
        cout<<real<<" + i"<<imag<<endl;
    }
};


int main()
{
    Complex obj1(4, 7); //4 + i7
    Complex obj2(6, 9); //6 + i9

    Complex obj3;

    obj3 = obj1 + obj2;
    obj3.print();

    //Complex obj3; // error

    //obj3 = obj1 + obj2; // error // obj1.Add(obj2);

    return 0;
}
