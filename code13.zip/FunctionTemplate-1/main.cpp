#include <iostream>

using namespace std;

//Function Template
template <class T>
T Add(T a, T b)
{
    cout<<(a + b)<<endl;
}

int main()
{
    cout<<"Addition of Integers:"<<endl;
    Add(10, 20);
    cout<<endl;

    cout<<"Addition of Float:"<<endl;
    Add(14.35f, 45.78f);
    cout<<endl;

    cout<<"Addition of Double:"<<endl;
    Add(14.35, 45.78);
    cout<<endl;

    return 0;
}
