#include <iostream>

using namespace std;

//Function Template
template <class T>
T Swap(T a, T b)
{
    T temp = a;
    a = b;
    b = temp;

    cout<<"a is: "<<a<<" "<<"b is: "<<b<<endl;
}

int main()
{
    cout<<"Swapping of Integers:"<<endl;
    Swap(10, 20);
    cout<<endl;

    cout<<"Swapping of Float:"<<endl;
    Swap(14.35f, 45.78f);
    cout<<endl;

    cout<<"Swapping of Double:"<<endl;
    Swap(14.35, 45.78);
    cout<<endl;

    return 0;
}
