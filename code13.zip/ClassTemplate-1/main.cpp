#include <iostream>

using namespace std;

template <class T>
class Calculator
{
private:
    T a, b;

public:

    void setData(T x, T y)
    {
        a = x;
        b = y;
    }

    void getData()
    {
        cout<<"Addition is:"<<(a + b)<<endl;
        cout<<"Subtraction is:"<<(a - b)<<endl;
        cout<<"Multiplication is:"<<(a * b)<<endl;
        cout<<"Division is:"<<(a / b)<<endl<<endl;
    }
};

int main()
{
    Calculator<int> obj1;
    obj1.setData(30, 20);

    Calculator<float> obj2;
    obj2.setData(30.67f, 78.9f);

    Calculator<double> obj3;
    obj3.setData(76.7, 89.7);

    obj1.getData();
    obj2.getData();
    obj3.getData();

    return 0;
}
