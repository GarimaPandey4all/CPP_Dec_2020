#include <iostream>

using namespace std;

class DC
{
public:
    int a, b;

    DC()
    {
        a = 10;
        b = 20;
    }

    void showData()
    {
        cout<<"a is:"<<a<<endl;
        cout<<"a is:"<<b<<endl;
    }
};



int main()
{
    DC obj;

    obj.showData();

    return 0;
}
