#include <iostream>

using namespace std;

class CC
{
public:
    int a;

    CC(int x)
    {
        a = x;
    }

    CC(CC &t) // Copy Constructor
    {
        a = t.a;
    }
};


int main()
{
    CC obj1(5); // Called Parametrized Constructor

    CC obj2(obj1); //Called Copy Constructor

    cout<<"A of obj2 is:"<<obj2.a;

    return 0;
}
