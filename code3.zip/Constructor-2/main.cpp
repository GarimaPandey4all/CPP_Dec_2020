#include <iostream>

using namespace std;

class Myclass
{
public:
    Myclass(); // constructor declaration
};

Myclass :: Myclass() // :: - Scope Resolution Operator
{
    cout<<"This is constructor example";
}


int main()
{
    Myclass obj;

    return 0;
}
