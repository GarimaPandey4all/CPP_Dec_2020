#include <iostream>

using namespace std;

/*

    Constructor:
    It is a special type of function because both class name and constructor name are same.
    It is used to initialize the instance variables.
    No need to instantiate/Called the constructor. It is called automatically
    when object is created.

*/


class Myclass
{
public:
    Myclass() // Constructor
    {
        cout<<"This is constructor example";
    }
};

int main()
{
    Myclass obj;

    return 0;
}
