#include <iostream>

using namespace std;

class Myclass
{
public:
    void showData(); // constructor declaration
};

void Myclass :: showData() // :: - Scope Resolution Operator
{
    cout<<"This is Normal function example";
}


int main()
{
    Myclass obj;

    obj.showData();

    return 0;
}
