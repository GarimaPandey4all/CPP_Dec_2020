#include <iostream>

using namespace std;

class PC
{
public:
    int a, b;

    PC(int x, int y) // Parameterized Constructor
    {
        a = x;
        b = y;
    }

    void showData()
    {
        cout<<"Addition is:"<<(a + b)<<endl;
    }
};


int main()
{
    PC pc(10, 20);

    pc.showData();

    return 0;
}
